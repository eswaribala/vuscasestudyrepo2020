package com.virtusa.ecommerce.model;

import java.time.LocalDate;

import org.springframework.data.annotation.Id;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import lombok.Data;

@Data
public class DeliverySchedule {
	
	private long productId;
	private long availableQty;
	@DateTimeFormat(iso=ISO.DATE)
	private LocalDate requestedDate;
	@DateTimeFormat(iso=ISO.DATE)
	private LocalDate plannedDeliveryDate;

}
