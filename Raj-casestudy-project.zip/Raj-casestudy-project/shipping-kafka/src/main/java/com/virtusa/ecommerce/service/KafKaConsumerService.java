package com.virtusa.ecommerce.service;

import java.time.LocalDate;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.virtusa.ecommerce.model.StockStatusHistory;
import com.virtusa.ecommerce.model.User;
import com.virtusa.ecommerce.repositories.ShippingRepository;

@Service
public class KafKaConsumerService 
{
	@Autowired
	ShippingRepository shippingRepository;
	
	private final Logger logger 
		= LoggerFactory.getLogger(KafKaConsumerService.class);
	
	
	
	@KafkaListener(topics = "${general.topic.name}", 
			groupId = "${general.topic.group.id}")
	public void consume(String message) {
		logger.info(String.format("Message recieved -> %s", message));
		//System.out.println(String.format("Message recieved -> %s", message));
		
		String[] data = message.split(",");
		
		
		StockStatusHistory stockStatusHistory = new StockStatusHistory();
		
		stockStatusHistory.setHistoryId(new Random().nextInt(1000000));
		stockStatusHistory.setProductId(Long.parseLong(data[0]));
		stockStatusHistory.setQty(Long.parseLong(data[2]));
		stockStatusHistory.setTimeStamp(LocalDate.now());
		shippingRepository.save(stockStatusHistory);
		logger.info(String.format("Message Stored in Mongo -> %s", message));
	}

	@KafkaListener(topics = "${user.topic.name}", 
			groupId = "${user.topic.group.id}",
			containerFactory = "userKafkaListenerContainerFactory")
	public void consume(User user) {
		logger.info(String.format("User created -> %s", user));
		System.out.println(String.format("User created -> %s", user));
	}
}
