package com.virtusa.ecommerce.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.virtusa.ecommerce.models.StockStatusHistory;

public interface ShippingRepository extends MongoRepository<StockStatusHistory, Long>{

}
