package com.virtusa.ecommerce.controller;

import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.ecommerce.dto.UserCreationDTO;
import com.virtusa.ecommerce.models.UserAccount;
import com.virtusa.ecommerce.service.UserCommandService;

@RestController
public class UserCommandController {

	@Autowired
	private UserCommandService userCommandService;
	
	@PostMapping("/useraccount/v1.0")
	public CompletableFuture<UserAccount> addUserAccount(@RequestBody UserCreationDTO userCreationDTO){
		return userCommandService.createAccount(userCreationDTO);
	}
}
