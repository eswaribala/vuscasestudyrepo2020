package com.virtusa.ecommerce.projection;

import org.axonframework.eventhandling.EventHandler;
import org.axonframework.queryhandling.QueryHandler;
import org.axonframework.queryhandling.QueryUpdateEmitter;
import org.springframework.stereotype.Component;

import com.virtusa.ecommerce.events.UserCreatedEvent;
import com.virtusa.ecommerce.models.UserAccount;
import com.virtusa.ecommerce.query.FindUserNameQuery;
import com.virtusa.ecommerce.repository.UserRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@RequiredArgsConstructor
@Component
public class UserAccountProjection {
	

    private final UserRepository repository;
    private final QueryUpdateEmitter updateEmitter;
	
	   @EventHandler
	    public void on(UserCreatedEvent event) {
	        log.debug("Handling a User Account creation command {}", event.getUserName());
	        UserAccount userAccount = new UserAccount(
	                event.getUserName(),
	                event.getPassword()
	        );
	        this.repository.save(userAccount);
	    }

	    @QueryHandler
	    public UserAccount handle(FindUserNameQuery query) {
	        log.debug("Handling FindUserNameQuery query: {}", query);
	        return this.repository.findById(query.getUserName()).orElse(null);
	    }
}
