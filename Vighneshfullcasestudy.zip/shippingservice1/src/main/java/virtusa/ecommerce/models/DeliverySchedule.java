package virtusa.ecommerce.models;

import java.time.LocalDate;

import lombok.Data;

@Data
public class DeliverySchedule {

	private long productId;
	private LocalDate requestedDate;
	private LocalDate plannedDeliveryDate;
	private long availableQty;
	public long getProductId() {
		return productId;
	}
	public void setProductId(long productId) {
		this.productId = productId;
	}
	public LocalDate getRequestedDate() {
		return requestedDate;
	}
	public void setRequestedDate(LocalDate requestedDate) {
		this.requestedDate = requestedDate;
	}
	public LocalDate getPlannedDeliveryDate() {
		return plannedDeliveryDate;
	}
	public void setPlannedDeliveryDate(LocalDate plannedDeliveryDate) {
		this.plannedDeliveryDate = plannedDeliveryDate;
	}
	public long getAvailableQty() {
		return availableQty;
	}
	public void setAvailableQty(long availableQty) {
		this.availableQty = availableQty;
	}
	
	
	
}
