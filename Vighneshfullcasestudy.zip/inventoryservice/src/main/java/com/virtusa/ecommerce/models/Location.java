package com.virtusa.ecommerce.models;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
@Entity
@Table(name="Location")

public class Location {
	@Id
	@Column(name="Regional_Code")
	private long regionalCode;
	@Column(name="Address",nullable = false,length = 150)
	private String address;
	@Column(name="Contact_Number")
	private long contactNumber;
	
	public long getRegionalCode() {
		return regionalCode;
	}
	public void setRegionalCode(long regionalCode) {
		this.regionalCode = regionalCode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	
	

}
