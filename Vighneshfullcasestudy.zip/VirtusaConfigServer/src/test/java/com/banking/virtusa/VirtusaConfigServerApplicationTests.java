package com.banking.virtusa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtusaConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
